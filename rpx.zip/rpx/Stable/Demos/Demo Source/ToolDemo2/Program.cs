using System;
using System.Collections.Generic;
using System.Text;

namespace ToolDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("Hello World from Tool 2");
            Console.ResetColor(); 
        }
    }
}
