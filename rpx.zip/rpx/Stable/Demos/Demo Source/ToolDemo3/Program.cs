using System;
using System.Collections.Generic;
using System.Text;

namespace ToolDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("Hello World from Tool 3");
            Console.ResetColor(); 
        }
    }
}
