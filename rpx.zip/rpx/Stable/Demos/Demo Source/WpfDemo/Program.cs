﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfDemo
{	
	static class Program
	{
		[STAThread]
		static void Main()
		{
			App app = new App();
			app.InitializeComponent();
			app.Run();
		}
    }
}
