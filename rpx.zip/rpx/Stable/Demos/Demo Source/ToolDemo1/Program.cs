using System;
using System.Collections.Generic;
using System.Text;

namespace ToolDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan; 
            Console.WriteLine("Hello World from Tool 1");
            Console.ResetColor(); 
        }
    }
}
